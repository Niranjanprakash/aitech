import os
import smtplib
from email.message import EmailMessage
from dotenv import load_dotenv

load_dotenv()

smtp_host = os.getenv("SMTP_HOST", "smtp.gmail.com")
smtp_port = int(os.getenv("SMTP_PORT", "587"))
smtp_username = os.getenv("SMTP_USERNAME", "").strip()
smtp_password = os.getenv("SMTP_PASSWORD", "").strip()
admin_email = os.getenv("ADMIN_EMAIL", "").strip()

print(f"Testing SMTP with:")
print(f"Host: {smtp_host}:{smtp_port}")
print(f"Username: {smtp_username}")
print(f"Admin Email: {admin_email}")
print()

message = EmailMessage()
message["Subject"] = "Test Email | AITechPulze Quote System"
message["From"] = smtp_username
message["To"] = admin_email

message.set_content("""
This is a test email from AITechPulze quote system.

Test Details:
- Full Name: Rajesh Kumar
- Phone: +91 9876543210
- Email: rajesh.kumar@example.com
- Project Type: Website Development
- Description: Need an e-commerce website with payment gateway integration

If you received this email, your SMTP configuration is working correctly!
""")

try:
    with smtplib.SMTP(host=smtp_host, port=smtp_port, timeout=20) as server:
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(smtp_username, smtp_password)
        server.send_message(message)
    
    print("✅ SUCCESS! Test email sent successfully.")
    print(f"Check inbox: {admin_email}")
except smtplib.SMTPAuthenticationError as e:
    print(f"❌ SMTP Authentication Failed: {e}")
    print("Check your Gmail App Password")
except Exception as e:
    print(f"❌ Error: {e}")
